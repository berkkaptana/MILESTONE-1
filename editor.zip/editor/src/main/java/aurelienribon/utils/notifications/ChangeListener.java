package aurelienribon.utils.notifications;

/**
 * @author Aurelien Ribon | http://www.aurelienribon.com
 */
public interface ChangeListener {
    public void propertyChanged(Object source, String propertyName);
}
